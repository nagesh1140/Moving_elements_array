﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment
{
    class Program
    {
        static void output(int[] a)
        {
            Console.WriteLine("the array elements are=");
            for(int x=0;x<a.Length;x++)
            {
                Console.Write(a[x]+"\t");
                if(x==4 || x==9 || x==14 || x==19)
                {
                    Console.WriteLine();  
                }
            }
        }
        static void Main(string[] args)
        {
            int[] a = { 0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
            output(a);

            for (; ; )
            {
                Console.WriteLine("\n2:press to move down");
                Console.WriteLine("4:press to move left");
                Console.WriteLine("6:press to move right");
                Console.WriteLine("8:press to move up");
                int b = int.Parse(Console.ReadLine());

                switch (b)
                {
                    case 2:

                        for (int i = 0; i < a.Length; i++)
                        {
                            if (a[i] == 1 && i <= 19)
                            {
                                a[i + 5] = a[i];
                                a[i] = 0;
                                output(a);
                                break;
                            }
                        }
                        break;

                    case 4:
                        for (int i = 0; i < a.Length; i++)
                        {
                            if (a[i] == 1 && i >=1)
                            {
                                if (i > 0 && i <= 4)
                                {
                                    a[i - 1] = a[i];
                                    a[i] = 0;
                                    output(a);
                                    break;
                                }
                                else if (i > 5 && i <= 9)
                                {
                                    a[i - 1] = a[i];
                                    a[i] = 0;
                                    output(a);
                                    break;
                                }
                                else if (i > 10 && i <= 14)
                                {
                                    a[i - 1] = a[i];
                                    a[i] = 0;
                                    output(a);
                                    break;
                                }
                                else if (i > 15 && i <= 19)
                                {
                                    a[i - 1] = a[i];
                                    a[i] = 0;
                                    output(a);
                                    break;
                                }
                                else if (i > 20 && i <= 24)
                                {
                                    a[i - 1] = a[i];
                                    a[i] = 0;
                                    output(a);
                                    break;
                                }
                                else { output(a); }
                            }
                        }
                        break;

                    case 6:
                        for (int i = 0; i < a.Length; i++)
                        {
                            if (a[i] == 1 && i<= a.Length - 1)
                            {
                                if (i >= 0 && i < 4)
                                {
                                    a[i + 1] = a[i];
                                    a[i] = 0;
                                    output(a);
                                    break;
                                }
                                else if (i >= 5 && i < 9)
                                {
                                    a[i + 1] = a[i];
                                    a[i] = 0;
                                    output(a);
                                    break;
                                }
                                else if (i >= 10 && i < 14)
                                {
                                    a[i + 1] = a[i];
                                    a[i] = 0;
                                    output(a);
                                    break;
                                }
                                else if (i >= 15 && i < 19)
                                {
                                    a[i + 1] = a[i];
                                    a[i] = 0;
                                    output(a);
                                    break;
                                }
                                else if (i >= 20 && i < 24)
                                {
                                    a[i + 1] = a[i];
                                    a[i] = 0;
                                    output(a);
                                    break;
                                }
                                else { output(a); }
                            }
                        }
                        break;

                    case 8:
                        for (int i = 0; i < a.Length; i++)
                        {
                            if (a[i] == 1 && i >=5)
                            {
                                a[i - 5] = a[i];
                                a[i] = 0;
                                output(a);
                                break;
                            }
                        }
                        break;

                }
            }
        }
    }
}
